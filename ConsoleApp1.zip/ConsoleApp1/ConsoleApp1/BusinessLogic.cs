﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MergeCatalog.Model;
using MergeCatalog.Helpers;

namespace MergeCatalog.Business
{
    public class MergeFiles
    {

        private FileOperations _fO = null;

        public MergeFiles()
        {
            //object initialization - can be done in DI
            _fO = new FileOperations();
        }

        public bool MergeCSV(String BarcodeFileA, String BarcodeFileB, String CatalogFileA, String CatalogFileB, String OutputFile)
        {
            List<Barcodes> ConflictingBarcodes = new List<Barcodes>();
            List<Barcodes> NonMatchingBarcodes = new List<Barcodes>();
            List<Catalog> Final_Catlog = new List<Catalog>();
            List<Result> Final_Result = new List<Result>();

            //file name is hardcode here but can be taken from command line
            var BarcodesA = _fO.ReadFile<Barcodes>(BarcodeFileA);
            var BarcodesB = _fO.ReadFile<Barcodes>(BarcodeFileB);
            var CatalogA = _fO.ReadFile<Catalog>(CatalogFileA);
            var CatalogB = _fO.ReadFile<Catalog>(CatalogFileB);

            try
            {
                //catalog with conflicating products
                if (BarcodesA != null && BarcodesB != null)
                {
                    foreach (var BCode in BarcodesB)
                    {
                        ConflictingBarcodes.AddRange(BarcodesA.Where(b => b.SupplierID == BCode.SupplierID && b.Barcode == BCode.Barcode));
                    }

                    foreach (var BCode in BarcodesA)
                    {
                        NonMatchingBarcodes.AddRange(BarcodesB.Where(b => b.SupplierID == BCode.SupplierID && b.Barcode == BCode.Barcode));
                    }
                }
                else
                {
                    Console.Write(@"barcodesA or/and barcodesB file(s) not found");
                }
                ConflictingBarcodes = ConflictingBarcodes.GroupBy(b => new { b.SupplierID, b.SKU }).Select(g => g.FirstOrDefault()).ToList();
                NonMatchingBarcodes = NonMatchingBarcodes.GroupBy(b => new { b.SupplierID, b.SKU }).Select(g => g.FirstOrDefault()).ToList();


                Helper.FillCatalog(ConflictingBarcodes, Final_Catlog);
                //consolidated catalog with conflicating
                if (CatalogA != null)
                {
                    Helper.FillResult(CatalogA, Final_Result, "A");
                    Helper.FillResult(CatalogB, Final_Result, "B");
                }
                else
                {
                    Console.Write(@"catalogA or/and CatalogB file(s) not found");
                }
                //remove conflicting catalogs            
                Helper.RemoveMatchingFromResult(NonMatchingBarcodes, Final_Result);
                _fO.WriteFile(OutputFile, Final_Result);
                foreach (var C in Final_Result)
                {
                    Console.WriteLine(C.SKU + " " + C.Description + " " + C.Source);
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

    }
}
