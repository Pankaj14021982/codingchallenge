﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MergeCatalog.Model;
using MergeCatalog.Helpers;
using MergeCatalog.Business;

namespace MergeCatalog
{
    class Program
    {
        static void Main(string[] args)
        {
            MergeFiles mergeFiles = new MergeFiles();
            bool success = false;
            success = mergeFiles.MergeCSV("input\\barcodesA.csv", "input\\barcodesB.csv", "input\\catalogA.csv", "input\\catalogB.csv", "output\\result.csv");
            if (success)
            {
                Console.WriteLine("File merge is successful and placed in output directory");
            }
            else {
                Console.WriteLine("File merge failed");
            }
            Console.ReadKey();
        }
       
    }
}

