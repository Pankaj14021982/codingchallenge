﻿using System;
using MergeCatalog.Business;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MaergeCatalogTest
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestMergeFile()
        {
            MergeFiles mergeFiles = new MergeFiles();
            bool success = false;
            success = mergeFiles.MergeCSV("input\\barcodesA.csv", "input\\barcodesB.csv", "input\\catalogA.csv", "input\\catalogB.csv", "output\\result.csv");
        }
    }
}
