﻿using MergeCatalog.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergeCatalog.Helpers
{
    class Helper
    {
        public static void FillResult(List<Catalog> Catlogs, List<Result> result, String Source = "A")
        {
            foreach (var b in Catlogs)
            {
                Result FC = new Result();
                FC.SKU = b.SKU;
                FC.Source = Source;
                FC.Description = b.Description;
                result.Add(FC);
            }
        }
        public static void FillCatalog(List<Barcodes> ConflictingBarcodes, List<Catalog> Final_Catlogs)
        {
            foreach (var b in ConflictingBarcodes)
            {
                Catalog FC = new Catalog();
                FC.SKU = b.SKU;
                Final_Catlogs.Add(FC);
            }
        }
        public static void RemoveMatchingFromResult(List<Barcodes> ConflictingBarcodes, List<Result> result)
        {
            foreach (var B in ConflictingBarcodes)
            {
                result.RemoveAll(x => x.SKU == B.SKU && x.Source != "A");
            }
        }
    }
}
