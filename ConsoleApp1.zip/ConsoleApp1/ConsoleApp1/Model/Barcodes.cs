﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergeCatalog.Model
{
    public class Barcodes
    {
        public int SupplierID {get; set;}
        public string SKU { get; set; }
        public string Barcode { get; set; }
        

    }
}
