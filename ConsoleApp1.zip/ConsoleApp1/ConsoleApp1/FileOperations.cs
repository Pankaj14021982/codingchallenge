﻿using CsvHelper;
using MergeCatalog.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergeCatalog
{
    public class FileOperations
    {

        public List<T> ReadFile<T>(string FileName)
        {

            using (var reader = new StreamReader(FileName))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                return csv.GetRecords<T>().ToList();
            }

            return null;
        }


        public void WriteFile(string FileName, List<Result> result)
        {

            using (var writer = new StreamWriter(FileName))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(result);
            }

            
        }
    }
}
